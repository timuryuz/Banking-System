#include "bank.h"

char* read();

int main()
{
	char *ID_str;
	int ID;
	
	//initialize bank and account list heads to null
	bank *banks = NULL;
	account *accounts = NULL;

	while(TRUE)
	{
		/*fprintf(stdout, "%-2s  %-13s\t%-2s  %-13s\n", "ID","Transaction","ID","Transaction");
		fprintf(stdout, "%-2s  %-13s\t%-2s  %-13s\n", "1", "Terminate","5", "Print Account");
		fprintf(stdout, "%-2s  %-13s\t%-2s  %-13s\n", "2", "New Bank", "6", "Deposit");
		fprintf(stdout, "%-2s  %-13s\t%-2s  %-13s\n", "3", "Print Bank", "7", "Withdrawal");
		fprintf(stdout, "%-2s  %-13s\t%-2s  %-13s\n", "4", "New Account", "8", "Close Account");
		fprintf(stdout, "Enter transaction ID:  ");*/
		ID_str = read();
		ID = atoi(ID_str);
		free(ID_str);
		
	
		if(ID == 1)
		{
			//free everything
			//free(input);
			exit(1);
		}
		else if(ID == 2)
		{
			new_bank(&banks);	
		}
		else if(ID == 3)
		{
			print_bank(&banks, &accounts);
		}
		else if(ID == 4)
		{
			new_account(&accounts);
		}
		else if(ID == 5)
		{
			print_account(&accounts);
		}
		else if(ID == 6)
		{
			deposit(&accounts);
		}
		else if(ID == 7)
		{
			withdrawal(&accounts);
		}
		else if(ID == 8)
		{
			close_account(&accounts);
		}
	}	
}

char* read() //reads standard input until a new line, and dynamically allocates memory
{
	int size = 10; //base size of 10 bytes

	char *input = (char*)malloc(sizeof(char)*size);
	if(input == NULL)
		fprintf(stderr, "Error: malloc fail.");

	int c;
	int index = 0;
	while((c = getchar()) != '\n' && c != EOF) //read until new line or end of input
	{
		if(index == size - 1) //if index reaches max size, reallocate more memory
		{
			size *= 2;
			char* new_input = (char*)realloc(input, size*sizeof(char));
			if(new_input == NULL)
				fprintf(stderr, "Error: realloc fail.");
			input = new_input;
		}
		input[index] = (char)c;
		index++;
	}
	input[index] = '\0';
	
	return input;	
}
















