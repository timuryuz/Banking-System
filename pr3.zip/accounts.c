#include "bank.h"

void new_account(account **head);
void print_account(account **head);
void deposit(account **head);
void withdrawal(account **head);
void close_account(account **head);

void new_account(account **head)
{
	//read in values, set them equal the struct variables
        char *account_lastname = read();
	char *account_firstname = read();
        char *account_address = read();
        char *account_city = read();
        char *account_state = read();
        char *account_zip = read();
        int zip = atoi(account_zip);
	char *account_bank = read();
	char *acc_number = read();
	int number = atoi(acc_number);

        account* new_Account = (account*)malloc(sizeof(account));
        new_Account->acc_lastname = account_lastname;
	new_Account->acc_firstname = account_firstname;
        new_Account->acc_address = account_address;
        new_Account->acc_city = account_city;
        new_Account->acc_state = account_state;
        new_Account->acc_zip = zip;
	new_Account->acc_bank = account_bank;
	new_Account->number = number;
	new_Account->acc_balance = 0;
        new_Account->next = *head;

        free(account_zip);

        *head = new_Account;
}

void print_account(account **head) //print account in required format
{
	char *num = read();
	int number = atoi(num);
	free(num);

	int found = FALSE;
	
	account* curr;
	for(curr = *head; curr; curr = curr->next)
	{
		if(curr->number == number)
		{
			found = TRUE;
			fprintf(stdout, "***\n");
			fprintf(stdout, "Name:  %s, %s\n", curr->acc_lastname, curr->acc_firstname);
			fprintf(stdout, "Bank:  %s\n", curr->acc_bank);
			fprintf(stdout, "Account Number:  %d\n", curr->number);
			fprintf(stdout, "Address:  %s, %s, %s  %d\n", curr->acc_address, curr->acc_city, curr->acc_state, curr->acc_zip);	
			fprintf(stdout, "Balance:  $%.2f\n", curr->acc_balance);
		}
	}
	if(found == FALSE) //not required, but display message if account is not found
		fprintf(stdout, "Account number '%d' not found.\n", number);
}

void deposit(account **head)
{
	if(!head) //check in case there are no accounts
	{
		fprintf(stderr, "Error: Account list head is NULL");
	}
	else
	{
		char *acc_number = read();
        	int number = atoi(acc_number);
		free(acc_number); //free string value
		//need to test if account number exists 
        	char *deposit = read();
        	float deposit_amount = atof(deposit); //deposit amount contains decimal values so use atof() instead of atoi()
		free(deposit); //free string value

        	account* curr;
        	for(curr = *head; curr; curr = curr->next)
        	{
                	if(curr->number == number)
                        	curr->acc_balance += deposit_amount; //add deposit amount to balance if the account number matches
       		}
	}
}

void withdrawal(account **head)
{
        if(!head)
        {
                fprintf(stderr, "Error: Account list head is NULL");
        }
        else
        {
                char *acc_number = read();
                int number = atoi(acc_number);
		free(acc_number);
		//need to test if account number exists
                char *withdrawal = read();
                float withdrawal_amount = atof(withdrawal);
		free(withdrawal);

                account* curr;
                for(curr = *head; curr; curr = curr->next)
                {
                        if(curr->number == number)
                                curr->acc_balance -= withdrawal_amount; //remove withdrawal amount from balance if the accout number matches
                }
        }
}

void close_account(account **head)
{
	char *acc_number = read();
	int number = atoi(acc_number);
	free(acc_number);

	account *curr = *head;
	account *prev = NULL;

	while(curr) //loop to traverse the account list
	{
		if(curr->number == number) //match account struct number to desired account to be closed
		{
			if(prev == NULL) //head deletion
				*head = curr->next;
			else
				prev->next = curr->next; //detatch node from list
		
			//free all dynamically allocated values
			free(curr->acc_lastname); 
			free(curr->acc_firstname);
			free(curr->acc_address);
			free(curr->acc_city);
			free(curr->acc_state);
			free(curr->acc_bank);

			free(curr); //free node itself

			break;
		}
		
		//if node is node found, simply move to the next node
		prev = curr;
		curr = curr->next;		
	}
}




