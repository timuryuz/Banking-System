#include "bank.h"

void new_bank(bank **head);
void print_bank(bank **bank_head, account **acc_head);
float holdings(account **head, char* bank_name);

void new_bank(bank **head) //reads in values using function and assings them to struct values
{
	char *bank_name = read();
	char *bank_address = read();
	char *bank_city = read();
	char *bank_state = read();
	char *bank_zip = read();
	int zip = atoi(bank_zip); //convert zip code from string to integer

	bank* new_Bank = (bank*)malloc(sizeof(bank));
	new_Bank->bank_name = bank_name;
	new_Bank->bank_address = bank_address;
	new_Bank->bank_city = bank_city;
	new_Bank->bank_state = bank_state;
	new_Bank->bank_zip = zip;
	new_Bank->next = *head;

	free(bank_zip); //free the string zip code

	*head = new_Bank;
}

void print_bank(bank **bank_head, account **acc_head)
{
	char *name = read();
	float bank_holdings = holdings(acc_head, name); //calculate bank holdings for printing
	int found = FALSE;
	
	bank* curr;
	for(curr = *bank_head; curr; curr = curr->next)
	{
		if(strcmp(curr->bank_name, name) == 0) //compare the struct value of the bank name to the input bank name
		{
			found = TRUE;
			fprintf(stdout, "***\n");
			fprintf(stdout, "Bank:  %s\n", curr->bank_name);
			fprintf(stdout, "Address:  %s, %s, %s  %d\n", curr->bank_address, curr->bank_city, curr->bank_state, curr->bank_zip);
			fprintf(stdout, "Holdings:  $%.2f\n", bank_holdings);			
		}	
	}
	if(found == FALSE) //not required, but print message if bank is not found
		fprintf(stdout, "Bank name '%s' not found.\n", name);

	free(name);
}

float holdings(account **head, char* bank_name) //calculate holdings but traversing through account list
{
	account* curr;
	float holdings = 0;
	
        for(curr = *head; curr; curr = curr->next)
        {
		if(strcmp(curr->acc_bank, bank_name) == 0) //if the account's bank matches the current bank being printed, update the holdings
			holdings += curr->acc_balance;
        }
	
	return holdings;
}
