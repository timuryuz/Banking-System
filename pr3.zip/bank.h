#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define TRUE 1
#define FALSE 0

typedef struct bank_
{
	char *bank_name;
	char *bank_address;
	char *bank_city;
	char *bank_state;
	int bank_zip;
	struct bank_ *next;	
} bank;

typedef struct account_
{
	char *acc_lastname;
	char *acc_firstname;
        char *acc_address;
        char *acc_city;
        char *acc_state;
        int acc_zip;
	char *acc_bank;
	int number;
	double acc_balance;
        struct account_ *next;
} account;

char* read();
void new_bank(bank **head);
void print_bank(bank **bank_head, account **acc_head);
void new_account(account **head);
void deposit(account **head);
void withdrawal(account **head);
